# Example of authentication via jwt on fastapi
